Ten projekt potrzebuje biblioteki SQLite jdbc.
Biblioteka jest dostępna tutaj:
https://github.com/xerial/sqlite-jdbc/releases/download/3.44.1.0/sqlite-jdbc-3.44.1.0.jar
a plik jar należy umieścić w folderze lib.