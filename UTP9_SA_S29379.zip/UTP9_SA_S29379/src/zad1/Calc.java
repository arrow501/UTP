/**
 *
 *  @author Święch Aleksander S29379
 *
 */

package zad1;


public class Calc {
}  
