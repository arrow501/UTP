/**
 *
 *  @author Święch Aleksander S29379
 *
 */

package zad2;


public class Purchase {
}  
